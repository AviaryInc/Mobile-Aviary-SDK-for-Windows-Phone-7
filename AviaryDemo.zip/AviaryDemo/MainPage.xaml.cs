﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;
using System.IO;
using System.Windows.Media.Imaging;
using Microsoft.Xna.Framework.Media;
using AviarySDK;
using System.Windows.Threading;
using System.Diagnostics;
using Microsoft.Phone.Info;

namespace AviaryDemo
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            ShowMemory();
        }

        private void ShowMemory()
        {
            GC.Collect();
            var cuMemUsage = (long)DeviceStatus.ApplicationCurrentMemoryUsage;
            var maxMemUsage = (long)DeviceStatus.DeviceTotalMemory;
            var pkMemUsage = (long)DeviceStatus.ApplicationPeakMemoryUsage;
            var ulMemLimit = (long)DeviceStatus.ApplicationMemoryUsageLimit;

            cuMemUsage /= 1024 * 1024;
            maxMemUsage /= 1024 * 1024;
            pkMemUsage /= 1024 * 1024;
            ulMemLimit /= 1024 * 1024;

            Debug.WriteLine(String.Format("Current Memory : {0} MB, Peak Memory : {1} MB, Usage Limit : {2} MB, Total Memory : {3} MB, ", cuMemUsage, pkMemUsage, ulMemLimit, maxMemUsage));
        }

        private void ChoosePhoto_Click(object sender, RoutedEventArgs e)
        {
            PhotoChooserTask photoChooserTask = new PhotoChooserTask();
            photoChooserTask.Completed += new EventHandler<PhotoResult>(photoChooserTask_Completed);
            photoChooserTask.Show();
        }

        void photoChooserTask_Completed(object sender, PhotoResult e)
        {
            if (e.TaskResult == TaskResult.OK)
            {
                Stream stream = e.ChosenPhoto;
                // ProgressLoading.Visibility = Visibility.Visible;

                AviaryTask aviaryTask = new AviaryTask(stream, themeColor: "32A9FF");
                aviaryTask.Completed += new EventHandler<AviaryTaskResultArgs>(aviaryTask_Completed);
                aviaryTask.Show();

                //AviaryPhotoGeniusApply aviaryPhotoGenius = new AviaryPhotoGeniusApply(stream, new float[4]);
                //aviaryPhotoGenius.Completed += new EventHandler<AviaryPhotoGeniusApplyResultArgs>(aviaryPhotoGenius_Completed);
                //aviaryPhotoGenius.Execute();

                //AviaryPhotoGeniusScores aviaryPhotoGenius = new AviaryPhotoGeniusScores(stream);
                //aviaryPhotoGenius.Completed += new EventHandler<AviaryPhotoGeniusScoresResultArgs>(aviaryPhotoGenius_Completed);
                //aviaryPhotoGenius.Execute();
            }
        }

        void aviaryPhotoGenius_Completed(object sender, AviaryPhotoGeniusScoresResultArgs e)
        {
            //  ProgressLoading.Visibility = Visibility.Collapsed;
            ShowMemory();
            if (e.AviaryResult == AviaryResult.OK)
            {
                //e.Predicts;
                //e.Scores;
                //e.TotalScore;
            }
            else
            {
                aviaryTask_Error(e.Exception);
            }
        }

        void aviaryPhotoGenius_Completed(object sender, AviaryPhotoGeniusApplyResultArgs e)
        {
            // ProgressLoading.Visibility = Visibility.Collapsed;
            ShowMemory();
            if (e.AviaryResult == AviaryResult.OK)
            {
                AviaryImage.Source = e.PhotoResult;
            }
            else
            {
                aviaryTask_Error(e.Exception);
            }
        }

        void aviaryTask_Completed(object sender, AviaryTaskResultArgs e)
        {
            //ProgressLoading.Visibility = Visibility.Collapsed;
            ShowMemory();
            if (e.AviaryResult == AviaryResult.OK)
            {
                AviaryImage.Source = e.PhotoResult;
                using (var stream = new MemoryStream())
                {
                    // Save the picture to the WP7 media library
                    e.PhotoResult.SaveJpeg(stream, e.PhotoResult.PixelWidth, e.PhotoResult.PixelHeight, 0, 100);
                    stream.Seek(0, SeekOrigin.Begin);
                    new MediaLibrary().SavePicture(DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss"), stream);
                }
            }
            else
            {
                aviaryTask_Error(e.Exception);
            }
        }

        void aviaryTask_Error(Exception ex)
        {
            if (ex == null)
                return;

            if (ex.Message == AviaryError.StreamNull)
            {
                // Input stream can't be null
            }
            else if (ex.Message == AviaryError.FeaturesEmpty)
            {
                // Features list determines which tools are exposed in the Aviary editor and cannot be null or empty
                //
            }
            else if (ex.Message == AviaryError.ImageBig)
            {
                // The image cannot exceed 8 mega pixels
                //
            }
            else if (ex.Message == AviaryError.AdjustmentsEmpty)
            {
                // The adjustment array passed into Photo Genius Apply is not valid.
                // The array must be of 4 float values and the array can't be empty or null
                //
            }
            else
            {
                // This is to handle any error thrown by the system
                //
            }
        }

        private void TakePhoto_Click(object sender, RoutedEventArgs e)
        {
            CameraCaptureTask cameraCaptureTask = new CameraCaptureTask();
            cameraCaptureTask.Completed += new EventHandler<PhotoResult>(cameraCaptureTask_Completed);
            cameraCaptureTask.Show();
        }

        void cameraCaptureTask_Completed(object sender, PhotoResult e)
        {
            if (e.TaskResult == TaskResult.OK)
            {
                Stream stream = e.ChosenPhoto;

                AviaryTask aviaryTask = new AviaryTask(stream, themeColor: "32A9FF");
                aviaryTask.Completed += new EventHandler<AviaryTaskResultArgs>(aviaryTask_Completed);
                aviaryTask.Show();

                //AviaryPhotoGeniusApply aviaryPhotoGenius = new AviaryPhotoGeniusApply(stream, new float[4]);
                //aviaryPhotoGenius.Completed += new EventHandler<AviaryPhotoGeniusApplyResultArgs>(aviaryPhotoGenius_Completed);
                //aviaryPhotoGenius.Execute();

                //AviaryPhotoGeniusScores aviaryPhotoGenius = new AviaryPhotoGeniusScores(stream);
                //aviaryPhotoGenius.Completed += new EventHandler<AviaryPhotoGeniusScoresResultArgs>(aviaryPhotoGenius_Completed);
                //aviaryPhotoGenius.Execute();
            }
        }
    }
}